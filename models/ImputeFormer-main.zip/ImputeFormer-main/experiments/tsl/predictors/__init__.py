from .base_predictor import Predictor

predictor_classes = ['Predictor']

__all__ = predictor_classes
