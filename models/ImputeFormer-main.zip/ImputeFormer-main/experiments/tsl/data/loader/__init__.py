from .dataloader import StaticGraphLoader
